# NSIGHT Spring 전체 설정 파일 패키지

## 구조
nh.marketing.com → Apache → Tomcat DeltaManager Cluster → 17 WAR → Spring Boot → HikariCP → MyBatis → RDW/ADW

## 포함 파일
- spring/config/common/application.yml
- spring/config/common/application-session.yml
- spring/config/common/application-datasource.yml
- spring/config/common/application-mybatis.yml
- spring/config/common/application-transaction.yml
- spring/config/common/application-security.yml
- spring/config/common/application-management.yml
- spring/config/common/application-kafka.yml
- spring/config/common/application-cache.yml
- spring/config/common/application-multipart.yml
- spring/config/common/application-scheduler.yml
- spring/config/dev/application-dev.yml
- spring/config/stg/application-stg.yml
- spring/config/prd/application-prd.yml
- spring/logback/logback-spring.xml
- spring/templates/web.xml

## 적용 기준
- 외장 Tomcat WAR 배포
- Tomcat DeltaManager 세션 복제
- 모든 WAR에 <distributable/> 적용
- Session Idle Timeout 60분
- Absolute Session Timeout 8시간은 애플리케이션 공통 Filter/Interceptor에서 구현
- Hikari connectionTimeout은 SQL 실행시간이 아니라 Pool 대기시간
- MyBatis default-statement-timeout은 SQL 실행시간 통제
