# NSIGHT Apache 전체 설정 파일

구조:
nh.marketing.com → Apache HTTPD → Tomcat Cluster(17 WAR, DeltaManager)

포함 파일:
- apache/httpd.conf
- apache/conf.d/00-mpm.conf
- apache/conf.d/10-security.conf
- apache/conf.d/20-ssl.conf
- apache/conf.d/30-proxy-common.conf
- apache/conf.d/40-balancer-nsight.conf
- apache/conf.d/50-logging.conf
- apache/conf.d/90-status.conf
- apache/vhosts/nh-marketing.conf

주의:
- SSL 인증서 경로는 운영 환경에 맞게 수정해야 합니다.
- Tomcat IP/Port는 실제 WAS 주소로 수정해야 합니다.
- Sticky Session은 JSESSIONID + Tomcat jvmRoute 기준입니다.
- Tomcat DeltaManager를 사용하므로 모든 Tomcat 노드에 동일한 17개 WAR가 배포되어야 합니다.
